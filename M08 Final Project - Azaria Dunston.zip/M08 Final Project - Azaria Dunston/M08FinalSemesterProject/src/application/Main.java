//Azaria Dunston
//12-17-2022
//Simple Mathematics Quiz Application

package application;

import OtherClasses.Lesson;
import QuizClasses.AdditionQuiz;
import QuizClasses.DivisionQuiz;
import QuizClasses.MultiplicationQuiz;
import QuizClasses.Quiz;
import QuizClasses.SubtractionQuiz;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;


public class Main extends Application {
	public static final int QUIZ_LENGTH = 5;
	public static String subject = "Addition";
	public static int difficulty = 1;
	public static Label currentSetting = new Label("Subject: " + subject + "\t Difficulty: " + difficulty);
	static boolean end = false;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			
			Button quizBtn = new Button("Take Quiz");
			Button lessonBtn = new Button("Read Lesson");
			Button settingsBtn = new Button("Settings");
			
			GridPane root = new GridPane();
			root.setVgap(20);
			root.add(new Label("Math Review App"), 0, 0);
			root.add(quizBtn, 0, 1);
			root.add(lessonBtn, 0, 2);
			root.add(settingsBtn, 0, 3);
			root.add(currentSetting, 0, 4);
			
			StackPane rootAlt = new StackPane();
			rootAlt.setAlignment(Pos.CENTER);
			//rootAlt.getChildren().add(quizBtn);
			//quizBtn.setLayoutY(100);
			
			quizBtn.setOnAction(e -> {primaryStage.close(); OpenQuizWindow(primaryStage);});
			lessonBtn.setOnAction(e -> {primaryStage.close(); OpenLessonWindow(primaryStage);});
			settingsBtn.setOnAction(e -> {primaryStage.close(); OpenSettingsWindow(primaryStage);});
			
			Scene scene = new Scene(root,200,200);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setResizable(false);
			primaryStage.setScene(scene);
			primaryStage.show();
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
//QUIZ WINDOW-----------------------------------------------------------------------------------------------------------
	public static void OpenQuizWindow(Stage mainStage) {
		GridPane qPane = new GridPane();
		int index;
		int answer = 2;	
		Quiz quiz;
		
		switch (subject) {
		case "Addition":
			quiz = new AdditionQuiz(QUIZ_LENGTH, difficulty);
			break;
		case "Subtraction":
			quiz = new SubtractionQuiz(QUIZ_LENGTH, difficulty);
			break;
		case "Multiplication":
			quiz = new MultiplicationQuiz(QUIZ_LENGTH, difficulty);
			break;
		case "Division":
			quiz = new DivisionQuiz(QUIZ_LENGTH, difficulty);
			break;
		default:
			quiz = new AdditionQuiz(QUIZ_LENGTH, difficulty);
		}
		
		Label question = new Label(quiz.askQuestion());
		Label feedback = new Label("");
		TextField userAnswer = new TextField();
		Button submit = new Button("Check");
		Button nextQuestion = new Button("Next Question");
		nextQuestion.setDisable(true);
		Button backMain = new Button("Quit to Main");
		
		qPane.add(new Label(subject + " Quiz"), 0, 0);
		qPane.add(question, 0, 1);
		qPane.add(userAnswer, 1, 1);
		qPane.add(feedback, 0, 2);
		qPane.add(submit, 0, 3);
		qPane.add(nextQuestion, 1, 3);
		qPane.add(backMain, 0,4);
		
		Scene qScene = new Scene(qPane, 400, 300);
		Stage quizStage = new Stage();
		quizStage.setResizable(false);
		quizStage.setTitle("Quiz on " + subject);
		
		//Checking answer
		submit.setOnAction(e -> {
			try {
				switch(quiz.gradeQuestion(Integer.parseInt(userAnswer.getText()))) {
				case 0:
					feedback.setText("Wrong! The answer was " + Integer.toString(quiz.getAnswer()));
					break;
				case 1:
					feedback.setText("Correct!");
					break;
				case 2:
					feedback.setText("Wrong! The answer was " + Integer.toString(quiz.getAnswer()));
					end = true;
					break;
				case 3:
					feedback.setText("Correct!");
					end = true;
					break;
				}
			
				nextQuestion.setDisable(false);
				submit.setDisable(true);
			}
			catch(NumberFormatException n) {
				feedback.setText("Please enter a whole number");
			}
		});
		
		//Display next question
		nextQuestion.setOnAction(e -> {
			if(end) {
			 	quizStage.close();
			 	end = false;
			 	OpenResultsWindow(mainStage, quiz.getScore());
			}
			else {
				feedback.setText("");
				quiz.nextQuestion();
				question.setText(quiz.askQuestion());
				nextQuestion.setDisable(true);
				submit.setDisable(false);
			}
		});
		
		backMain.setOnAction(e -> {quizStage.close(); mainStage.show();});
		
		quizStage.setScene(qScene);
		
		quizStage.show();
	}

//RESULTS WINDOW-----------------------------------------------------------------------------------------------------------
	private static void OpenResultsWindow(Stage mainStage, int score) {
		StackPane rPane = new StackPane();
		rPane.setAlignment(Pos.CENTER);
		Button returnBtn = new Button("Return to Main");
	
		
		
		rPane.getChildren().add(new Label("You got " + score + " out of " + QUIZ_LENGTH + " correct." ));
		rPane.getChildren().add(returnBtn);
		rPane.setAlignment(returnBtn, Pos.BOTTOM_CENTER);
		
		Scene rScene = new Scene(rPane, 200, 200);
		Stage resultsStage = new Stage();
		resultsStage.setResizable(false);
		resultsStage.setTitle("Final Results");
		returnBtn.setOnAction(e -> {resultsStage.close(); mainStage.show();});
		resultsStage.setScene(rScene);
		resultsStage.show();
	
	}

//LESSON WINDOW-----------------------------------------------------------------------------------------------------------
	public static void OpenLessonWindow(Stage mainStage) {
		Lesson lesson = new Lesson();
		if (subject == "Addition") {
			lesson = new Lesson("Addition", "Addition is when you add numbers together and get a bigger number.\n"
					+ "For example, let's add 3 to 2. To do that, we'd count to 3: 1, 2, 3.\n"
	                + "Then we would count 2 numbers past 3: 1, 2, 3, 4 ,5. So 3 + 2 = 5.\n");
		}
		else if (subject == "Subtraction") {
			lesson = new Lesson("Subtraction", "Subtraction is when you take numbers from each other and get a smaller number.\n"
					+ "For example, let's subtract 3 to 2. To do that, we'd count to 3: 1, 2, 3.\n" 
					+ "Then we would take away the last 2 numbers, which leaves us with: 1. So 3 - 2 = 1.\n");
		}
		else if (subject == "Multiplication") {
			lesson = new Lesson("Multiplication", "Multiplication is when you take a number and add it to itself a certain number of times.\n"
					+ "For example, let's multiply 2 by 3. To do that, we'd count to 2 once: 1, 2.\n"
					+ "Then, since we are multiplying by 3, not 1, we'd count 2 numbers further: 3, 4.\n"
					+ "Then 2 numbers further for the third time: 5, 6. In total, we've counted 2 numbers 3 times and got to 6. So 2 * 3 = 6.\n");
		}
		else if (subject == "Division") {
			lesson = new Lesson("Division", "Division is when you see how many of one number can fit into another.\n"
					+ "For example, Let's divide 7 by 2. To do that, we'd count to 7,\n"
					+ "but after every time we count 2 numbers, we'll say 'then' as a sort of marker: "
	                + "1, 2, then, 3, 4, then, 5, 6, then, 7. Now we will count how many 'then's there are. There are 3. So 7 / 2 = 3.\n");
		}
		
		GridPane lPane = new GridPane();
		Button backMain = new Button("Back to Main");
		
		lPane.add(new Label("Quick Lesson on " + subject), 0, 0);
		lPane.add(new Label(lesson.getLesson()), 0, 1);
		
		lPane.add(backMain, 0, 2);
		
		Scene lScene = new Scene(lPane, 400, 200);
		Stage lessonStage = new Stage();
		lessonStage.setTitle("Lesson on " + subject);
		
		backMain.setOnAction(e -> {lessonStage.close(); mainStage.show();});
		
		lessonStage.setScene(lScene);
		
		lessonStage.show();
	}
	
//SETTINGS WINDOW-----------------------------------------------------------------------------------------------------------
	public static void OpenSettingsWindow(Stage mainStage) {
		GridPane sPane = new GridPane();
		
		Button backMain = new Button("Back to Main");

		//Subject Buttons Group
		ToggleGroup sToggle = new ToggleGroup();

		RadioButton optAdd = new RadioButton("Addition");
		RadioButton optSub = new RadioButton("Subtraction");
		RadioButton optMul = new RadioButton("Multiplication");
		RadioButton optDiv = new RadioButton("Division");
		
		optAdd.setToggleGroup(sToggle);
		optSub.setToggleGroup(sToggle);
		optMul.setToggleGroup(sToggle);
		optDiv.setToggleGroup(sToggle);
		
		//Difficulty Buttons Group
		ToggleGroup dToggle = new ToggleGroup();
		
		RadioButton opt1 = new RadioButton("1");
		RadioButton opt2 = new RadioButton("2");
		RadioButton opt3 = new RadioButton("3");
		
		opt1.setToggleGroup(dToggle);
		opt2.setToggleGroup(dToggle);
		opt3.setToggleGroup(dToggle);
		
		//Putting everything in the sPane
		sPane.add(new Label("Settings"), 0, 0);
		
		sPane.add(new Label("Subject:"), 0, 1);
		sPane.add(optAdd, 0, 2);
		sPane.add(optSub, 1, 2);
		sPane.add(optMul, 0, 3);
		sPane.add(optDiv, 1, 3);
		//Label selectedS = new Label("What'd ya choose?");
		//sPane.add(selectedS, 0, 4);
		
		sPane.add(new Label("Difficulty:"), 0, 5);
		sPane.add(opt1, 0, 6);
		sPane.add(opt2, 1, 6);
		sPane.add(opt3, 0, 7);
		//Label selectedD = new Label("What'd ya choose?");
		//sPane.add(selectedD, 0, 8);
		
		sPane.add(backMain, 0, 9);
		
		if (subject == "Addition") {
			optAdd.setSelected(true);
		}
		else if (subject == "Subtraction") {
			optSub.setSelected(true);
		}
		else if (subject == "Multiplication") {
			optMul.setSelected(true);
		}
		else if (subject == "Division") {
			optDiv.setSelected(true);
		}
		
		if (difficulty == 1) {
			opt1.setSelected(true);
		}
		else if (difficulty == 2) {
			opt2.setSelected(true);
		}
		else if (difficulty == 3) {
			opt3.setSelected(true);
		}
		
		Scene sScene = new Scene(sPane, 400, 300);
		Stage settingsStage = new Stage();
		settingsStage.setResizable(false);
		settingsStage.setTitle("Settings");
		
		sToggle.selectedToggleProperty().addListener(new ChangeListener<Toggle>()
		{
			public void changed(ObservableValue<? extends Toggle> ob, Toggle o, Toggle n)
			{
				RadioButton rb = (RadioButton)sToggle.getSelectedToggle();
				
				if (rb != null) {
					String s = rb.getText();
					subject = s;
					//selectedS.setText(s);
					currentSetting.setText("Subject: " + subject + "\t Difficulty: " + difficulty);
					
				}
			}
		});
		
		dToggle.selectedToggleProperty().addListener(new ChangeListener<Toggle>()
		{
			public void changed(ObservableValue<? extends Toggle> ob, Toggle o, Toggle n)
			{
				RadioButton rb = (RadioButton)dToggle.getSelectedToggle();
				
				if (rb != null) {
					String d = rb.getText();
					if (d == "1") {
						difficulty = 1;
					}
					else if (d == "2") {
						difficulty = 2;
					}
					else if (d == "3") {
						difficulty = 3;
					}
					
					//selectedD.setText(d);
					currentSetting.setText("Subject: " + subject + "\t Difficulty: " + difficulty);
					
				}
			}
		});
		
		backMain.setOnAction(e -> {settingsStage.close(); mainStage.show();});
		
		settingsStage.setScene(sScene);
		
		settingsStage.show();
		
	}
	
//MAIN METHOD------------------------------------------------------------------------------------------
	public static void main(String[] args) {
		launch(args);
	}
}
