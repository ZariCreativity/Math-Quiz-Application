package OtherClasses;


public class Lesson {
	String type;
	String lesson;
	
	public Lesson() {
		
	}
	public Lesson(String type, String lesson){
		this.type = type;
		this.lesson = lesson;
	}
	
	void setType(String type) {
		this.type = type;
	}
	
	String getType() {
		return this.type;
	}
	
	public String getLesson() {
		return this.lesson;
	}
}
