package QuizClasses;

public abstract class Quiz {
	int score = 0;
	int index;
	int length;
	int level;
	String[] questions;
	int[] answers;
	
	Quiz(){
		
	}
	
	Quiz(int length, int level){
		this.length = length;
		this.level = level;
		questions = new String[this.length];
		answers = new int[this.length];
		this.index = 0;
	}
	
	public void setScore(int score){
		this.score = score;
	}
	public void setLength(int length){
		this.length = length;
	}
	public void setLevel(int level){
		this.level = level;
	}
	
	public int getScore() {
		return this.score;
	}
	public int getLength() {
		return this.length;
	}
	public int getLevel() {
		return this.level;
	}
	
	public void nextQuestion() {
		this.index++;
	}
	
	public void previousQuestion() {
		this.index--;
	}
	
	public abstract void generateQuestions();
	
	public String askQuestion() {
		//System.out.println("index: " + this.index + "\n Question: " + this.questions[this.index]);
		return this.questions[this.index];
	}
	
	public int getAnswer() {
		//System.out.println("index: " + this.index + "\n Answer: " + this.answers[this.index]);
		return this.answers[this.index];
	}
	
	public int gradeQuestion(int answer) {
		//0 - wrong answer
		//1 - right answer
		//2 - wrong answer & end of test
		//3 - right answer & end of test
		//System.out.println(this.answers[index]);
		if(this.index + 1 >= this.questions.length) {
			if (this.answers[this.index] == answer) {
				score++;
				return 3;
			}
			else return 2;
		}
		
		else if (this.answers[this.index] == answer) {
			score++;
			return 1;
		}
		else return 0;
	};
}
