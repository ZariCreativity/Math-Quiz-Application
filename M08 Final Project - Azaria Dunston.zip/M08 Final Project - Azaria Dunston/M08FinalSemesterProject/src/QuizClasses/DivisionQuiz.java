package QuizClasses;

public class DivisionQuiz extends Quiz {
	
	public DivisionQuiz(int length, int level){
		super(length, level);
		generateQuestions();
	}
	
	@Override
	public void generateQuestions() {
		int num1 = 0;
		int num2 = 0;
		for(int i = 0; i < this.length; i++) {
			switch (this.level) {
			case 1:
				num1 = (int) (5 + Math.random()*5);
				num2 = (int) (1 + Math.random()*5);
				break;
			case 2:
				num1 = (int) (30 + Math.random()*30);
				num2 = (int) (10 + Math.random()*20);
				break;
			case 3:
				num1 = (int) (300 + Math.random()*300);
				num2 = (int) (100 + Math.random()*200);
				break;
			default:
				num1 = (int) (Math.random()*10);
				num2 = (int) (Math.random()*10);
			}
					
			this.questions[i] = Integer.toString(num1) + " / " + Integer.toString(num2) + " = ";
			this.answers[i] = (int)(num1 / num2);
			//System.out.println(this.questions[i]);
			//System.out.println(this.answers[i]);
		}		
	}
	
}
