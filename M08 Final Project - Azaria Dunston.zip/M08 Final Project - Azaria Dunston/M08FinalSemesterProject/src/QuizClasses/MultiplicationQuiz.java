package QuizClasses;

public class MultiplicationQuiz extends Quiz{
	
	public MultiplicationQuiz(int length, int level){
		super(length, level);
		generateQuestions();
	}
	
	@Override
	public void generateQuestions() {
		int num1 = 0;
		int num2 = 0;
		for(int i = 0; i < this.length; i++) {
			switch (this.level) {
			case 1:
				num1 = (int) (Math.random()*6);
				num2 = (int) (Math.random()*6);
				break;
			case 2:
				num1 = (int) (5 + Math.random()*15);
				num2 = (int) (5 + Math.random()*15);
				break;
			case 3:
				num1 = (int) (100 + Math.random()*200);
				num2 = (int) (100 + Math.random()*200);
				break;
			default:
				num1 = (int) (Math.random()*10);
				num2 = (int) (Math.random()*10);
			}
					
			this.questions[i] = Integer.toString(num1) + " * " + Integer.toString(num2) + " = ";
			this.answers[i] = num1 * num2;
			//System.out.println(this.questions[i]);
			//System.out.println(this.answers[i]);
		}		
	}

}
